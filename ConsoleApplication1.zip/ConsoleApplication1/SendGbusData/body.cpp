#pragma once
#include "header.h"
#include <vector>

SendGbusDataClass::SendGbusDataClass(int *pInt, int arrSize)
{
	for (int i = 0; i < arrSize; i++)
	{
		vec.push_back(pInt[i]);
	}
}

double SendGbusDataClass::sumArray()
{
	int cumSum = 0;
	for (int i = 0; i < vec.size(); i++)
	{
		cumSum += vec[i];
	}
	return cumSum;
}

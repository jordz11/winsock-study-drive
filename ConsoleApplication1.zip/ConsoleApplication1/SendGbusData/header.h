#pragma once
#include <vector>

using namespace std;
class SendGbusDataClass
{
public:
	SendGbusDataClass(int* pInt, int arrSize);
	double sumArray();

private:
	vector<int> vec;

};

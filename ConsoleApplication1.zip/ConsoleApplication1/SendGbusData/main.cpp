#pragma once
#include "header.h"

void main()
{
	int noElement = 3;
	int* myArray = new int[noElement];

	myArray[0] = 10;
	myArray[1] = 15;
	myArray[2] = 75;

	SendGbusDataClass cC = SendGbusDataClass(myArray, noElement);

}



